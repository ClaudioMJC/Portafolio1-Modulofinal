/*
Claudio Mauricio Jiménez Castro
Fecha: 31/08/2023
 */

import java.util.Scanner;
import javax.swing.*;

/**
 *
 * @author Claudio
 */
public class Portafolio1 {

 

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //j. Instrucciones de entrada y salida de consola
         /*
          Scanner teclado =new Scanner(System.in);
            System.out.println("ingrese su nombre: ");   
            String x = teclado.nextLine();   
            System.out.println("Hola, " + x + "! Bienvenido a Java.");
            */
         
            //k. Envío de mensajes con la clase swing
            /*
            String mensaje =JOptionPane.showInputDialog("Escriba un mensaje");
            JOptionPane.showMessageDialog(null, "¡Este es un mensaje Swing!" + mensaje);
            */
         
         // b. Tipos de datos booleanos
        /*
        boolean esMayorDeEdad = true; // Variable que indica si es mayor de edad
        boolean tienePermiso = true; // Variable que indica si tiene permiso (puede ser false, lo que provocaría que 
        //la variable puedeEntrar sea false al no cumplirse ambas condiciones)
        // Operación lógica para determinar si puede entrar (ambas condiciones deben ser verdaderas)
        boolean puedeEntrar = esMayorDeEdad && tienePermiso;
        // Imprimir los resultados
        System.out.println("¿Es mayor de edad? " + esMayorDeEdad); // Imprime "true"
        System.out.println("¿Tiene permiso? " + tienePermiso);     // Imprime "true"
        System.out.println("¿Puede entrar? " + puedeEntrar);       // Imprime "true" (ambas condiciones son verdaderas)
         */
        //c. Operadores relacionales
        /*
        int x = 5;
        int y = 10;
        //teniendo en cuenta que se devuelve true o false dependiendo de que sea o no cierto con la comparación
        //que se haga con los operadores racionales
        boolean igual = x == y;  // x es igual a y
        boolean distinto = x != y;  // x es distinto de y
        boolean mayorQue = x > y;  // x es mayor que y
        boolean menorQue = x < y;  // x es menor que y
        boolean mayorOigual = x >= y;  // x es mayor o igual que y
        boolean menorOigual = x <= y;  // x es menor o igual que y
        // Imprimir resultados que son true o false tomando en cuenta las variables x y
        System.out.println("¿x es igual a y? " + igual);
        System.out.println("¿x es distinto de y? " + distinto);
        System.out.println("¿x es mayor que y? " + mayorQue);
        System.out.println("¿x es menor que y? " + menorQue);
        System.out.println("¿x es mayor o igual que y? " + mayorOigual);
        System.out.println("¿x es menor o igual que y? " + menorOigual);
         */
        //d. Operadores lógicos
        /*
        boolean a = true;
        boolean b = false;
        boolean resultadoAND = a && b;  // AND lógico Ambas condiciones deben cumplirse
        boolean resultadoOR = a || b;   // OR lógico Al menos una de las dos debe cumplirse como true
        boolean resultadoNOT = !a;      // NOT lógico  cambia un valor booleano a su opuesto
        // Imprimir resultados
        System.out.println("a AND b: " + resultadoAND);
        System.out.println("a OR b: " + resultadoOR);
        System.out.println("NOT a: " + resultadoNOT);
         */
        //e. Prueba que en Java si no asignamos valores al declarar variables,
        //éstas tienen valores por defecto.
        /*
        int numero=0;          // Valor por defecto: 0
        double decimal=0.0;      // Valor por defecto: 0.0
        boolean flag=false;        // Valor por defecto: false
        char caracter='\u0000';       // Valor por defecto: '\u0000'
        String cadena=null;       // Valor por defecto: null
        System.out.println("Número: " + numero);
        System.out.println("Decimal: " + decimal);
        System.out.println("Flag: " + flag);
        System.out.println("Caracter: " + caracter);
        System.out.println("Cadena: " + cadena);
         */
                
                
        //f. Asigne adecuadamente el nombre a los identificadores
        /*
        int edadPersona = 30;  // Usamos un nombre descriptivo para la variable
        System.out.println("Edad de la persona: " + edadPersona);
         */
                
                
        //g. Declara alguna constante, ponga a prueba que la constante no puede
        //ser modificada posterior a su declaración
        /*
        final double IVA = 0.13;  // Declaración de la constante junto con la palabra clave final
        //para indicar que no puede ser modificado
        System.out.println("Valor del IVA: " + IVA);
        // Intentamos modificar la constante (esto generará un error en el compilador)
        // IVA = 0.15;  // Esto dará un error de compilación
         */
        //h. Pruebe el uso de varios caracteres de escape
        /*
        System.out.println("Hola, esto es una línea.\nEsto está en una nueva línea.");
        System.out.println("Texto con\t\ttabulación.");
        System.out.println("Cita: \"Texto entre comillas\".");
        System.out.println("Apóstrofe: \'Texto entre apóstrofes\'."); //comillas simples
        System.out.println("Barra invertida: \\");
         */
                
        //i. Cree un tipo enumerado y pruebe su funcionamiento, investigue y cree
        //un ejemplo diferente al estudiado en clase con Enum.
          /*    
                Scanner scanner = new Scanner(System.in)) {
            System.out.println("Elija una categoría de alimento:");
            System.out.println("1. Fruta");
            System.out.println("2. Verdura");
            System.out.println("3. Carne");
            System.out.println("4. Lácteo");
            System.out.println("5. Pan");
            
            int opcion = scanner.nextInt();
             
            CategoriaAlimento seleccion = null;
            
            switch (opcion) {
                
                case 1:
                    seleccion = CategoriaAlimento.FRUTA;
                    System.out.println("Es una fruta saludable.");
                    break;
                case 2:
                    seleccion = CategoriaAlimento.VERDURA;
                    System.out.println("Es una opción saludable rica en nutrientes.");
                    break;
                case 3:
                    seleccion = CategoriaAlimento.CARNE;
                    System.out.println("Es una fuente de proteína.");
                    break;
                case 4:
                     seleccion = CategoriaAlimento.LACTEO;
                    System.out.println("Contiene calcio.");
                    break;
                case 5:
                    seleccion = CategoriaAlimento.PAN;
                    System.out.println("Es una fuente de carbohidratos.");
                    break;
                default:
                    System.out.println("Opción inválida.");
                    break;
            }
             enum CategoriaAlimento {
        FRUTA, VERDURA, CARNE, LACTEO, PAN
      }
            
        }
       */
       
        
        
              
        
        
        //SEGUNDA PARTE TRABAJO
        
        //a. Utilizar métodos de la clase string
        
        /*
        String texto = "Hola, mundo!";

        // Obtener la longitud del texto
        int longitud = texto.length();
        System.out.println("Longitud del texto: " + longitud);

        // Convertir el texto a mayúsculas
        String mayusculas = texto.toUpperCase();
        System.out.println("Texto en mayúsculas: " + mayusculas);

        // Reemplazar parte del texto
        String reemplazado = texto.replace("mundo", "amigo");
        System.out.println("Texto reemplazado: " + reemplazado);

        // Obtener la posición de la palabra "Hola"
        int posicion = texto.indexOf("Hola");
        System.out.println("Posición de 'Hola': " + posicion);

        // Extraer una parte del texto
        String subtexto = texto.substring(0, 5);
        System.out.println("Subtexto: " + subtexto);
        */
        
        //b. Realice conversiones de tipo String a int y double
        
        /*
         String numeroEntero = "123";
        int entero = Integer.parseInt(numeroEntero);
        System.out.println("Número entero: " + entero);

        String numeroDecimal = "3.14";
        double decimal = Double.parseDouble(numeroDecimal);
        System.out.println("Número decimal: " + decimal);
       */
        
        //c. Realice conversiones de tipos numéricos (int y double) a string
        
        /*
        int numeroE = 42;
        String enteroComoString = Integer.toString(numeroE);
        System.out.println("Entero como String: " + enteroComoString);

        double numeroD = 2.71828;
        String decimalComoString = Double.toString(numeroD);
        System.out.println("Decimal como String: " + decimalComoString);
        */
        
        //d. Realice comparaciones y concatenaciones entre strings
        
          String cadena1 = "Hola";
        String cadena2 = "amigos";

        // Comparación de cadenas
        boolean sonIguales = cadena1.equals(cadena2);
        System.out.println("¿Son iguales? " + sonIguales);

        // Concatenación de cadenas
        String concatenacion = cadena1 + ", " + cadena2 + "!";
        System.out.println("Concatenación: " + concatenacion);
        
        
        //PARTE 3 DEL PORTAFOLIO
        
        
          //a. Números aleatorios
          
          /*
        int numeroAleatorio = (int) (Math.random() * 10) + 1;
        System.out.println("Número aleatorio entre 0 y 10: " + numeroAleatorio);

        // Valor absoluto
        int valor = -42;
        int absoluto = Math.abs(valor);
        System.out.println("Valor absoluto de " + valor + ": " + absoluto);

        // Potencia
        double base = 2.0;
        double exponente = 3.0;
        double potencia = Math.pow(base, exponente);
        System.out.println(base + " elevado a la " + exponente + " es " + potencia);

        // Redondeo hacia arriba
        double decimal = 3.7;
        double redondeoArriba = Math.ceil(decimal);
        System.out.println("Redondeo hacia arriba de " + decimal + ": " + redondeoArriba);

        // Raíz cuadrada
        double numero = 25.0;
        double raizCuadrada = Math.sqrt(numero);
        System.out.println("Raíz cuadrada de " + numero + ": " + raizCuadrada);
        */
        
          
        //b. Tipos de datos int y double y realice conversiones de int a double
        
        /*
        int entero = 42;
        double decimal = 3.14;

        // Conversión de int a double
        double enteroComoDouble = (double) entero;
        System.out.println("Entero como double: " + enteroComoDouble);

        // Operaciones con tipos numéricos
        double suma = entero + decimal;
        double resta = decimal - entero;
        double multiplicacion = entero * decimal;
        double division = entero / decimal;

        System.out.println("Suma: " + suma);
        System.out.println("Resta: " + resta);
        System.out.println("Multiplicación: " + multiplicacion);
        System.out.println("División: " + division);
        */
        
        //c. Operadores aritméticos
        
        /*
         int a = 10;
        int b = 5;

        int suma = a + b;
        int resta = a - b;
        int multiplicacion = a * b;
        int division = a / b;
        int mod = a % b;

        System.out.println("Suma: " + suma);
        System.out.println("Resta: " + resta);
        System.out.println("Multiplicación: " + multiplicacion);
        System.out.println("División: " + division);
        System.out.println("Resto: " + mod);
        */
        //
        //d.Operadores de asignación
        
          int a = 10;
        int b = 5;

        a += b; // a = a + b
        System.out.println("a += b: " + a);  //El valor de a cambia en cada asingnación

        a -= b; // a = a - b
        System.out.println("a -= b: " + a);

        a *= b; // a = a * b
        System.out.println("a *= b: " + a);

        a /= b; // a = a / b
        System.out.println("a /= b: " + a);

        a %= b; // a = a % b
        System.out.println("a %= b: " + a);
                      
    }
   
     

}
